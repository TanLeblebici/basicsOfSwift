import UIKit

/*
var greeting = "Hello, playground"    //variables can be changed after initialization
greeting = "tan"                      //modifies variable rather than creatin a new variable
*/


/*
var age = 38
var population = 8_000_000    //int iniitialization
 */


/*
var str1 = """
This goes
over multiple
lines
"""
                        //multiple line strings
var str2 = """
This goes \
over multiple \
lines
"""
*/


/*
var pi = 3.141     // double
var awesome = true // boolean
*/


/*
var score = 85
var str = " Your score was \(score)"                   //String interpolation
var results = "The test results are here: \(str)"
*/


/*
let album: String = "Reputation"
let year: Int = 1989                    //Constants
let height: Dobule = 1.78
let taylorRocks: Bool = true
*/


/*
let beatles = [john, paul, george, ringo]       //Array initialization
beatles[1]                                      //Arrays can store many values inside them
var scores: [Int] = [10, 12, 9]
*/
//-----------------------------------------------------------------------------------------
/*

//SETS ARE COLLECTIONS OF VALUES JUST LIKE ARRAYS, EXCEPT THEY HAVE TWO DIFFERENCES
//1- ITEMS ARE NOT STORED IN ANY ORDER; THEY ARE STORED IN WHAT IS EFFECTIVELY A RANDOM ORDER.
//2- NO ITEM CAN APPEAR TWICE IN A SET; ALL ITEMS MUST BE UNIQUE
 
let colors = Set(["red", "green", "blue"])
 
let colors2 = Set(["red", "green", "blue", "red", "blue"])
 
//duplicates in oolors2 will be ignored final colors2 set will be [red, green, blue] once
*/


/*
//1- YOU CAN NOT ADD OR REMOVE ITEMS FROM A TUPLE; THEY ARE FIXED IN SIZE
//2- YOU CAN NOT CAHNGE THE TYPE OF ITEMS IN A TUPLE; THEY ALWAYS HAVE THE SAME TYPES THEY WERE //CREATED WITH
//3- YOU CAN ACCESS ITEMS IN A TUPLE USING NUMERICAL PISITIONS OR BY NAMING THEM BUT SWIFT WONT //LET YOU READ NUMBERS OR NAMES THAT DONT EXIST
 
var name = (first: "Taylor", last:"Swift")
name.0
name.first
 
 YOU CAN CHANGE THE VALUES INSIDE A TUPLE AFTER YOU CREATE IT, BUT NOT THE TYPES OF VALUES
 
*/


/*
let address = (house: 555, street: "Taylor avenue", city: "Nashville") //--> tuple -- precise position and name
let set = Set(["aardvarl", "astronaut", "azalea"]) //--> set-- unordered
let pythons = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"] //--> array -- ordered
*/


/*
 DICTIONARIES
let heights = [
    "Taylor Swift": 1.78,
    "Ed Sheeran": 1.73
]
heights["Taylor Swift"] --> identifier called key
 
let favoriteIceCream = [
"Paul": "Chocolate",
"Sophie"": "Vanilla"
]
favoriteIceCream["Charlotte", default: "Unknown"] //-->avoiding nil so it will print unknown                                                  //   there is no value for charlotte key so                                                 //   defining it as unknown
*/


/*
var teams = [String: String]()      Empty Dictionary
teams["Paul"] = "Red"               adding entry

var results = [Int]()               Empty int arr

var words = Set<String>()           Empty Set
var numbers = Set<Int>()
*/


/*
enum Result{
    case success
    case failure
}
let result1 = Result.success
 
enum Activity{
    case bored
    case running(destination: String)
    case talking(topic: String)
    case singing(volume: Int)
}
let talking = Activity.talking(topic: "football")

enum Planet: Int{
    case mercury
    case venus
    case earth
    case mars
}
let earth = Planet(rawValue: 2) //--> starting from 0 earrh will be given the number 2

enum Planet: Int{
    case mercury = 1       // --> now swift will assign 1 to mercury meaning that
    case venus                  earth is ow the third planet
    case earth
    case mars
}
*/
//-----------------------------------------------------------------------------------------

/*
let firstScore = 12
let secondScore = 4
let total = firstScore + secondScore
let difference = firstScore - secondScore     //--> ARITHMETIC OPERATORS
let product = firstScore * secondScore
let divide = firstScore / secondScore
let modulo = 13 % secondScore
 
let number = 465
let isMultiple = number.isMultiple(of: 7)  //--> checks if it is divide equally
*/


/*
let num1 = 42
let num2 = 42 + 42

let fakers = "Fakers gonna"               //  --> OPERATOR OVERLOADING
let action = fakers + "fake"

let firstHalf = ["John", "Paul"]
let secondHalf = ["George", "Ringo"]
let beatles = firstHalf + secondHalf

var score = 95
score -= 5
var quote = "The rain in Spain falls mainly on"    // --> Compund assignment operators
quote + = "Winter"
*/

/*
let num1 = 6
let num2 = 4

num1 == num2
num1 != num2
num1 < num2
num1 >= num2
"Taylor" <= "Swift"

enum Sizes: Comparable{
    case small
    case medium
    case large
}

let first = Sizes.small
let second = Sizes.large        //--> that will print true because small comes before large in
print(first < second)               the enum case list
*/

/*
let firstCard = 11
let secondCard = 10

if firstCard + secondCard == 2{
    print("Aces - lucky!")
}else if firstCard + secondCard == 21{  //-->CONDITIONS
    print("")
}else{
    print("Regular cards")
}
*/

/*
let age1 = 12
let age2 = 21

if age1 > 18 && age2 > 18{
    print("Both are over 18")      // --> COMBINING CONDITIONS
}

if age1 > 18 || age2 > 18{
    print("At least one is over 18")
}
*/

/*
let card1 = 11
let card2 = 10
print(card1 == card2 ? "Cards are the same" : "Cards are different")   // --> TERMARY OPERATOR

if card1 == card2 {
    print("Cards are the same")       // --> REGULAR CONDITION
}else{
    print("Cards are different")
}
*/

/*
let weather = "sunny"

switch weather{
case "rain":
    print("Being an umbrella")
case "snow":
    print("Wrap up warm")
case "sunny":
    print("Wear suncreen")
default:
    print("Enjoy your day!")
}

switch weather{
case "rain":
    print("Being an umbrella")
case "snow":
    print("Wrap up warm")
case "sunny":
    print("Wear suncreen")
    fallthrough
default:
    print("Enjoy your day!")
}
*/

/*
let score = 85
switch score{
case 0..<50:
    print("You failed")
case 50..<85:
    print("You did OK.")
default:
    print("You did great")
}

let names = ["Piper", "Alex", "Suzanne", "Gloria"]
print(names[0])
print(names[1...3])
print(names[1...])
*/

//-----------------------------------------------------------------------------------------

/*
// FOR LOOPS
let count = 1...10
for number in count{
    print("Number is \(number)")
}

let albums = ["Red", "1989", "Reputation"]

for album in albums{
    print("\(album) is on Apple Music")
}

print("Players gonna")
for _ in 1...5{
    print("play")
}

let names = ["Sterling", "Cyrill", "Lana", "Ray", "Pam"]

for _ in names{
    print(" [CENSORED] is a secret agent")
}
*/

/*
 //  WHILE LOOP
 
 var number = 1
 
 while number < 20{
     print(number)
     number += 1
}
*/

/*
 
//  DO-WHILE
 
var number = 1

repeat{
    print(number)
    number += 1
}while number <= 20

while false{
    print("this is false") //--> will never be executed
}

repeat{
    print("this is false") //--> will be executed once
}while false
*/

/*
// SKIPPING ITEMS
for i in 1...10{
    if i % 2 == 1{
        continue
    }
    print(i)
}
*/

/*
// INFINITE LOOP
var counter = 0

while true {
    print("")
    counter += 1
    
    if counter == 273{
        break
    }
}
*/

//-----------------------------------------------------------------------------------------

//      WRTINIG FUNCTIONS

/*
func printHelp() {
    let message = """
Welcome to MyApp!

Run this app inside a directory of images and
Myapp will resize them all into thumbnails
"""
    print(message)
}

printHelp() //--> CALLING FUNCTION
*/

/*
func square(number: Int){  //-->  FUNCTION WITH PARAMETER
    print(number * number)
}
square(number: 8)


func square2(number: Int) -> Int{  //--> returning
    return number * number
}
let result = square2(number: 9)
print(result)
*/


/*
//      PARAMETER LABELS
func sayHello(to name: String){   // --> INTERNALLY CALLED NAME BUT EXTERNALLY ITS CALLED TO
    print("Hello, \(name)!")
}
sayHello(to: "Tan")
*/

/*
//      OMITTING PARAMETER LABELS
func greet(_ person: String){
    print("Hello, \(person)!")
}
greet("Tan")
*/

/*
 
func greet(_ person: String, nicely: Bool = true){ --> GIVING DEFAULT PARAMETER TO NICELY
    if nicely == true{
        print("Hello \(person)")
    }else{
        print("Oh no, its \(person) again...")
    }
}

greet("Tan")
greet("Tan", nicely: false)
 
 func findDirections(from: String, to: String, route: String = "fastest", avoidHighways: Bool = false) {
     // code here
 }
 // As a result, we can call that same function in any of three ways:
 findDirections(from: "London", to: "Glasgow")
 findDirections(from: "London", to: "Glasgow", route: "scenic")
 findDirections(from: "London", to: "Glasgow", route: "scenic", avoidHighways: true)
 
*/

/*
//      VARIADIC FUNCTIONS CAN TAKE ANY NUMBER OF PARAMETERS
func square(numbers: Int...){
    for number in numbers{
        print("\(number) squared is \(number * number)")
    }
}

square(numbers: 1, 2, 3, 4, 5)
*/

/*
//THROWING FUNCTIONS
enum PasswordError: Error{
    case obvious
}

func checkPassword(_ password: String) throws -> Bool {
    if password == "password"{
        throw PasswordError.obvious
    }
    return true
}
*/

/*
//TRY-CATCH
do{
    try checkPassword("password")
    print("That password is good")
}catch{
    print("You can't use that password")
}
*/

/*
func doubleInPlace(number: inout Int){
    number *= 2
}

var myNum = 10
doubleInPlace(number: &myNum)
*/

//-----------------------------------------------------------------------------------------

/*
let driving = {
    print("I'm driving in my car") //--> BASIC CLOSURE
}
driving()
*/

/*
let driving = { (place: String) in
    print("I'm going to \(place) in my car") //--> ACCEPTING PARAMETERS IN A CLOSURE
}
driving("London")
*/

/*
func pay(user: String, amount: Int){    //--> FUNCTION
    //code
}

let payment = { (user: String, amount: Int) in //--> CLOSURE VERSION OF FUNCTION ABOVE
    //code
}
*/

/*
let driving = { ( place: String) in
    print("I'm going to \(place) in my car")
}

let drivingWithReturn = { (place : String) -> String in   //--> RETURNING VALUES FROM CLOSURE
    return "I'm going to \(place) in my car"
}

let message = drivingWithReturn("London")
print(message)
 
let payment = { () -> Bool in
    print("Paying an anonymous person...) // --> RETURNING VALUE FROM A CLOSURE WITHOUT PRMTR
    return true
}
*/

/*
let driving = {
    print("I'm diriving in my car")
}

func travel(action: () -> Void){
    print("I'm diriving in my car")
    action()
    print("I arrived")
}

travel(action: driving) // USING CLOSURE AS PARAMETER
*/

//-----------------------------------------------------------------------------------------

//                              CREATIMG STRUCTURES

/*
struct Album {
    let title: String
    let artist: String
    let year: Int
    
    func printSummary() {
        print("\(title) \(year) by \(artist)")
    }
}

let red = Album(title: "Red", artist: "Tan", year: 2012)
let wing = Album(title: "Wings", artist: "BTS", year: 2016)

print(red.title)
print(wing.artist)

red.printSummary()
wing.printSummary()
*/

/*
//              HOW TO COMPUTE PROPERTY VALUES DYNAMICALLY
struct Employee {
    let name: String
    var vacationRemaining: Int
    
    mutating func takeVacation(days: Int){
        if vacationRemaining > days{
            vacationRemaining -= days
            print("I'm going to vacation")
            print("Days remaining \(vacationRemaining)")
        }else{
            print("There aren't enough days remaining")
        }
    }
}

var tan = Employee(name: "Tan", vacationRemaining: 14)
tan.takeVacation(days: 5)
print(tan.vacationRemaining)
*/


//Variables and constants that belong to structs are called properties.
//Functions that belong to structs are called methods.
//When we create a constant or variable out of a struct, we call that an instance – you might create a dozen unique instances of the Album struct, for example.
//When we create instances of structs we do so using an initializer like this: Album(title:"Wings", artist: "BTS", year: 2016).


/*
 var tan1 = Employee(name: "Tan", vacationRemaining: 14)
 var tan2 = Employee.init(name: "Tan", vacationRemaining: 14)
 */

/*
struct Employee2 {
    let name: String
    var vacationRemaining: Int
}

var tan = Employee2(name: "Sterling Archer", vacationRemaining: 14)
tan.vacationRemaining -= 5
print(tan.vacationRemaining)
tan.vacationRemaining -= 3
print(tan.vacationRemaining)
*/

/*
struct Employee3 {
    let name: String
    var vacationAllocated = 14
    var vacationTaken = 0
    
    /* // 1
    var vacationRemainig: Int {
        vacationAllocated - vacationTaken
    }
    */
    
    var vacationRemaining: Int{ // 2
        get{
            vacationAllocated - vacationTaken
        }
        
        set{
            vacationAllocated = vacationTaken + newValue
        }
    }
    
}

/* //  1
var archer = Employee3(name: "Sterling archer", vacationAllocated: 14)
archer.vacationTaken += 4
print(archer.vacationRemainig)
archer.vacationTaken += 4
print(archer.vacationRemainig)
*/

/* //  2
var archer = Employee3(name: "Sterling archer", vacationAllocated: 14)
archer.vacationTaken += 3
archer.vacationRemaining = 5
print(archer.vacationAllocated)
*/

 */

/*
 
//                  HOW TO TAKE ACTION WHEN A PROPERTY CHANGES
struct Game {
    var score = 0
}

var game = Game()
game.score += 10
print("Score is now \(game.score)")
game.score -= 3
print("Score is now \(game.score)")
game.score += 1
*/

/*
struct Game {
    var score = 0 {
        didSet {
            print("Score is now \(score)")
        }
    }
}

var game = Game()
game.score += 10
game.score -= 3
game.score += 1
*/

/*
struct App {
    var contacts = [String]() {
        willSet {
            print("Current value is: \(contacts)")
            print("New value will be: \(newValue)")
        }

        didSet {
            print("There are now \(contacts.count) contacts.")
            print("Old value was \(oldValue)")
        }
    }
}

var app = App()
app.contacts.append("Adrian E")
app.contacts.append("Allen W")
app.contacts.append("Ish S")
*/

/*
struct Player {
    let name: String
    let number: Int

    init(name: String, number: Int) {
        self.name = name
        self.number = number
    }
}
*/


//There is no func keyword. Yes, this looks like a function in terms of its syntax, but Swift treats initializers specially.
//Even though this creates a new Player instance, initializers never explicitly have a return type – they always return the type of data they belong to.
//I’ve used self to assign parameters to properties to clarify we mean “assign the name parameter to my name property”.

/*
//          CUSTOM INITIALIZERS
struct Player {
    let name: String
    let number: Int

    init(name: String) {
        self.name = name
        number = Int.random(in: 1...99)
    }
}

let player = Player(name: "Megan R")
print(player.number)
*/

/*
struct Employee {
    var name: String
    var yearsActive = 0
}

extension Employee {
    init() {
        self.name = "Anonymous"
        print("Creating an anonymous employee…")
    }
}

// creating a named employee now works
let roslin = Employee(name: "Laura Roslin")

// as does creating an anonymous employee
let anon = Employee()
*/


//-----------------------------------------------------------------------------------------
//                HOW TO LIMIT ACCESS TO INTERNAL DATA WITH ACCESS CONTROL

// Use private for “don’t let anything outside the struct use this.”
// Use fileprivate for “don’t let anything outside the current file use this.”
// Use public for “let anyone, anywhere use this.”

/*
struct BankAccount{
    var funds = 0
    
    mutating func deposit(amount: Int){
        funds += amount
    }
    
    mutating func withdraw(amount: Int) -> Bool{
        if funds >= amount {
            funds -= amount
            return true
        }else{
            return false
        }
    }
}

var account = BankAccount()
account.deposit(amount: 3000)
let success = account.withdraw(amount: 200)
account.funds -= 2000 // --> WE CAN ACCESS TO THE FUNDS BECAUSE IT IS NOT PRIVATE
if success{
    print("Withdrew money successfuly")
}else{
    print("Failed to get money")
}

print(account.funds)

// TO PREVENT IT PRIVATE KEYWORD HAS TO BE USED
// private var funds = 0
// RUN THE CODES ABOVE AND BELOW TO SEE THE DIFFERENCE


struct BankAccount2{
    private var funds = 0
    
    mutating func deposit(amount: Int){
        funds += amount
    }
    
    mutating func withdraw(amount: Int) -> Bool{
        if funds >= amount {
            funds -= amount
            return true
        }else{
            return false
        }
    }
}

var account2 = BankAccount2()
account2.deposit(amount: 3000)
let success2 = account2.withdraw(amount: 200)
account2.funds -= 2000 // NOT GONNA RUN BECAUSE INACCESIBLE DUE TO PRIVATE KEYWORD
if success{
    print("Withdrew money successfuly")
}else{
    print("Failed to get money")
}
*/

//                            STATIC PROPERTIES AND METHODS

/*struct School {
    static var studentCount = 0

    static func add(student: String) {
        print("\(student) joined the school.")
        studentCount += 1
    }
}

School.add(student: "Taylor Swift")
print(School.studentCount)*/

// I haven’t created an instance of School – we can literally use add() and studentCount directly on the struct. This is because those are both static, which means they don’t exist uniquely on instances of the struct.

//To access non-static code from static code… you’re out of luck: static properties and methods can’t refer to non-static properties and methods because it just doesn’t make sense – which instance of School would you be referring to?

//To access static code from non-static code, always use your type’s name such as School.studentCount. You can also use Self to refer to the current type.

/*
struct AppData {
    static let version = "1.3 beta 2"
    static let saveFilename = "settings.json"
    static let homeURL = "https://www.hackingwithswift.com"
}

struct Employee {
    let username: String
    let password: String

    static let example = Employee(username: "cfederighi", password: "hairforceone")
}

Employee.example
*/

/*
You can create your own structs by writing struct, giving it a name, then placing the struct’s code inside braces.
 
Structs can have variable and constants (known as properties) and functions (known as methods)
If a method tries to modify properties of its struct, you must mark it as mutating.
 
You can store properties in memory, or create computed properties that calculate a value every time they are accessed.
 
We can attach didSet and willSet property observers to properties inside a struct, which is helpful when we need to be sure that some code is always executed when the property changes.

Initializers are a bit like specialized functions, and Swift generates one for all structs using their property names.

You can create your own custom initializers if you want, but you must always make sure all properties in your struct have a value by the time the initializer finishes, and before you call any other methods.

We can use access to mark any properties and methods as being available or unavailable externally, as needed.

It’s possible to attach a property or methods directly to a struct, so you can use them without creating an instance of the struct.
*/

//-----------------------------------------------------------------------------------------

//                              HOW TO CREATE CLASS
/*
class Game {
    var score = 0 {
        didSet {
            print("Score is now \(score)")
        }
    }
}

var newGame = Game()
newGame.score += 10
*/

/*
//                        HOW TO MAKE ONE CLASS INHERIT FROM ANOTHER

class Employee {  // --> SuperClass
    let hours: Int
    
    init(hours: Int){
        self.hours = hours
    }
    
    func printSummary(){
        print("I work \(hours) hours a day")
    }
}

class Developer: Employee {  // --> Subclass of Employee
    func work(){
        print("I'm writing code for \(hours) hours.")
    }
    
    override func printSummary() {
        print("Im a developer who will sometimes work \(hours) hours a day") // --> Overriding
    }
}

class Manager: Employee {   // --> Subclass of Employee
    func work() {
        print("I'm going to meetings for \(hours) hours.")
    }
}

let robert = Developer(hours: 8)
let joseph = Manager(hours: 10)
robert.work()
joseph.work()
let novall = Developer(hours: 9)
novall.printSummary()
*/


/*
//                          HOW TO ADD INITALIZERS FOR CLASSES

class vehicle {
    let isElectric: Bool
    
    init(isElectric: Bool){
        self.isElectric = isElectric
    }
}

class Car: vehicle {
    let isConvertible: Bool
    
    init(isElectric: Bool, isConvertible: Bool){
        self.isConvertible = isConvertible
        super.init(isElectric: isElectric) // --> Need to write init of superclass
    }
}

let teslaX = Car(isElectric: true, isConvertible: false)
*/

/*
//                              HOW TO COPY CLASSES

class user {
    var username = "Anonymous"
}

var user1 = user()

var user2 = user1
user2.username = "Swift"

print(user1.username)
print(user2.username)


class User {
    var username = "Anonymous"
    
    func copy() -> User {
        let user = User()
        user.username = username
        return user
    }
}
*/

/*
//                      HOW TO CREATE A DEINITIALIZER FOR A CLASS

class User {
    let id: Int
    
    init(id: Int){
        self.id = id
        print("User \(id): I'm alive")
    }
    
    deinit{
        print("User \(id): I'm dead!")
    }
}

for i in 1...3 {
    let user = User(id: i)
    print("User \(user.id): I'm in control!")
}


var users = [User]()

for i in 1...3{
    let user = User(id: i)
    print("User \(user.id): I'm in control!")
    users.append(user)
}

print("Loop is finished")
users.removeAll()
print("Array is clear!")
*/

/*
//                      HOW TO WORK WITH VARIABLES INSIDE CLASSES
class User {
    var name = "Paul"
}

let user  = User()
user.name = "Swift"
print(user.name)


class User2 {
    var name = "Paul"
}

var user2 = User2()
user2.name = "Swift"
user2 = User2()
print(user2.name)
*/

/*
//                          HOW TO CREATE AND USE PROTOCOLS

protocol Vehicle {
    var name: String { get }
    var currentPassengers: Int { get set }
    func estimateTime(for distance: Int) -> Int
    func travel(distance: Int)
}

struct Car: Vehicle {
    let name = "Car"
    var currentPassengers = 1
    func estimateTime(for distance: Int) -> Int {
        distance / 50
    }
    
    func travel(distance: Int) {
        print("I'm driving \(distance) km")
    }
    
    func openSunroof() {
        print("It's a nice day")
    }
}

struct Bicyle: Vehicle {
    let name = "Bicyle"
    var currentPassengers = 1
    func estimateTime(for distance: Int) -> Int {
        distance / 10
    }
    
    func travel(distance: Int) {
        print("I'm cycling \(distance) km")
    }
}

func commute(distance: Int, using vehicle: Car) {
    if vehicle.estimateTime(for: distance) > 100 {
        print("That's too slow! I'll try a different vehicle.")
    } else {
        vehicle.travel(distance: distance)
    }
}

func getTravelEstimates(using vehicles: [Vehicle], distance: Int) {
    for vehicle in vehicles {
        let estimate = vehicle.estimateTime(for: distance)
        print("\(vehicle.name): \(estimate) hours to travel \(distance)km")
    }
}

let car = Car()
commute(distance: 100, using: car)

let bike = Bicyle()
//commute(distance: 50, using: bike)

getTravelEstimates(using: [car, bike], distance: 150)
*/

//-----------------------------------------------------------------------------------------

/*
var winner: String? = nil
winner = "Daley Thompson"
if let name = winner {
    print("And the winner is... \(name)!")
}

func double(number: Int?) -> Int? {
    guard let number = number else {
        return nil
    }
    return number * 2
}
let input = 5
if let doubled = double(number: input) {
    print("\(input) doubled is \(doubled).")
}
*/

